@echo off
setlocal

REM ======================================================================
REM CX Watch Face Thumbnails - Uninstall
REM Creative eXtremes
REM ======================================================================

set "APPNAME=CX Watch Face Thumbnails"

set "INSTALLDIR=%LOCALAPPDATA%\CXWatchFaceThumbnails"

set "TARGET_DLL64=%INSTALLDIR%\CXWatchFaceThumbnail64.dll"
set "TARGET_DLL32=%INSTALLDIR%\CXWatchFaceThumbnail32.dll"

REM System32 = 64-bit
REM SysWOW64 = 32-bit

set "REGSVR32_64=%SystemRoot%\System32\regsvr32.exe"
set "REGSVR32_32=%SystemRoot%\SysWOW64\regsvr32.exe"


echo.
echo Uninstalling %APPNAME%...
echo.


REM ======================================================================
REM Unregister 64-bit handler
REM ======================================================================

if exist "%TARGET_DLL64%" (
    echo Unregistering 64-bit thumbnail handler...

    "%REGSVR32_64%" /s /u "%TARGET_DLL64%"

    if errorlevel 1 (
        echo WARNING: 64-bit DLL unregistration reported an error.
        echo Continuing with cleanup...
        echo.
    )
) else (
    echo 64-bit installed DLL was not found.
)


REM ======================================================================
REM Unregister 32-bit handler
REM ======================================================================

if exist "%TARGET_DLL32%" (
    echo Unregistering 32-bit thumbnail handler...

    "%REGSVR32_32%" /s /u "%TARGET_DLL32%"

    if errorlevel 1 (
        echo WARNING: 32-bit DLL unregistration reported an error.
        echo Continuing with cleanup...
        echo.
    )
) else (
    echo 32-bit installed DLL was not found.
)


REM ======================================================================
REM Stop Explorer so loaded shell extensions are released
REM ======================================================================

taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul


REM ======================================================================
REM Delete installed DLLs
REM ======================================================================

if exist "%TARGET_DLL64%" (
    del /f /q "%TARGET_DLL64%" >nul 2>&1
)

if exist "%TARGET_DLL32%" (
    del /f /q "%TARGET_DLL32%" >nul 2>&1
)


REM ======================================================================
REM Remove installation directory
REM ======================================================================

if exist "%INSTALLDIR%" (
    rd /s /q "%INSTALLDIR%" >nul 2>&1
)


REM ======================================================================
REM Restart Explorer
REM ======================================================================

start explorer.exe


echo.
echo ============================================================
echo Uninstall completed.
echo ============================================================
echo.

pause
endlocal
exit /b 0