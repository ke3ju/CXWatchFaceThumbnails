CX WATCH FACE THUMBNAILS
Creative eXtremes
========================

WHAT IT DOES
------------

CX Watch Face Thumbnails is a native 64-bit Windows Explorer thumbnail
provider for Samsung Watch Face Studio and Wear OS watch-face package files.

Supported file types:

    .WFS    Watch Face Studio project files
    .APK    Watch-face APK packages
    .AAB    Watch-face Android App Bundles

Instead of showing a generic application icon in Explorer, the extension reads
the preview image stored inside the watch-face file and displays it as the file
thumbnail.

The current preview locations are:

    .WFS    latest_preview.png
    .APK    res/drawable-nodpi-v4/preview.png
    .AAB    base/res/drawable-nodpi-v4/preview.png

Fallback APK/AAB preview paths are also supported for compatibility.


REQUIREMENTS
------------

    Windows 10 or Windows 11, 64-bit

The ZIP handling code is compiled into the DLL and PNG decoding uses Windows
Imaging Component, which is built into Windows.


INSTALLATION
------------

Keep these files together in the same folder:

    CXWatchFaceThumbnail64.dll
    Install.cmd
    Uninstall.cmd
    README.txt

Run:

    Install.cmd

The installer copies the DLL to:

    %LOCALAPPDATA%\CXWatchFaceThumbnails\

and registers it as the Explorer thumbnail provider for .WFS, .APK, and .AAB.

Administrator rights are not normally required because installation and COM
registration are performed for the current Windows user.


UNINSTALLATION
--------------

Run:

    Uninstall.cmd

The uninstaller unregisters the shell extension, removes the installed DLL,
and restarts Windows Explorer so the extension can be unloaded cleanly.


THUMBNAIL UPDATES
-----------------

Windows Explorer automatically refreshes the thumbnail when the underlying
watch-face file changes. No manual thumbnail-cache refresh should normally be
necessary.


IMPORTANT NOTES
---------------

The APK and AAB handlers are intended for watch-face packages containing the
supported embedded preview paths. They are not general-purpose APK/AAB preview
handlers.

The DLL may be stored anywhere, but once registered it should not be moved.
Install.cmd places it in a fixed per-user location so Windows Explorer always
knows where to load it from.

If the DLL is moved manually, unregister it before moving it and register it
again from the new location.


FILES
-----

    CXWatchFaceThumbnail64.dll
        Native 64-bit Windows Explorer thumbnail provider.

    Install.cmd
        Installs and registers the DLL for the current Windows user.

    Uninstall.cmd
        Unregisters and removes the installed DLL.

    README.txt
        This file.


COPYRIGHT
---------

Copyright © 2026 Creative eXtremes
All rights reserved.
