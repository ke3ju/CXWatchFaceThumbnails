@echo off
setlocal

REM ======================================================================
REM CX Watch Face Thumbnails - Install
REM Creative eXtremes
REM ======================================================================

set "APPNAME=CX Watch Face Thumbnails"

set "SOURCE_DLL64=%~dp0CXWatchFaceThumbnail64.dll"
set "SOURCE_DLL32=%~dp0CXWatchFaceThumbnail32.dll"

set "INSTALLDIR=%LOCALAPPDATA%\CXWatchFaceThumbnails"

set "TARGET_DLL64=%INSTALLDIR%\CXWatchFaceThumbnail64.dll"
set "TARGET_DLL32=%INSTALLDIR%\CXWatchFaceThumbnail32.dll"

REM ======================================================================
REM Registration tools
REM
REM System32  = 64-bit REGSVR32
REM SysWOW64  = 32-bit REGSVR32
REM ======================================================================

set "REGSVR32_64=%SystemRoot%\System32\regsvr32.exe"
set "REGSVR32_32=%SystemRoot%\SysWOW64\regsvr32.exe"


echo.
echo Installing %APPNAME%...
echo.


REM ======================================================================
REM Verify source DLLs
REM ======================================================================

if not exist "%SOURCE_DLL64%" (
    echo ERROR: CXWatchFaceThumbnail64.dll was not found beside Install.cmd.
    echo.
    pause
    exit /b 1
)

if not exist "%SOURCE_DLL32%" (
    echo ERROR: CXWatchFaceThumbnail32.dll was not found beside Install.cmd.
    echo.
    pause
    exit /b 1
)


REM ======================================================================
REM Create installation directory
REM ======================================================================

if not exist "%INSTALLDIR%" (
    mkdir "%INSTALLDIR%" >nul 2>&1

    if errorlevel 1 (
        echo ERROR: Unable to create:
        echo %INSTALLDIR%
        echo.
        pause
        exit /b 1
    )
)


REM ======================================================================
REM Unregister existing versions
REM ======================================================================

if exist "%TARGET_DLL64%" (
    echo Unregistering existing 64-bit thumbnail handler...
    "%REGSVR32_64%" /s /u "%TARGET_DLL64%" >nul 2>&1
)

if exist "%TARGET_DLL32%" (
    echo Unregistering existing 32-bit thumbnail handler...
    "%REGSVR32_32%" /s /u "%TARGET_DLL32%" >nul 2>&1
)


REM ======================================================================
REM Stop Explorer so an existing shell extension is released
REM ======================================================================

taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul


REM ======================================================================
REM Copy DLLs
REM ======================================================================

echo Copying 64-bit thumbnail handler...

copy /y "%SOURCE_DLL64%" "%TARGET_DLL64%" >nul

if errorlevel 1 (
    echo.
    echo ERROR: Unable to copy:
    echo %TARGET_DLL64%
    echo.
    start explorer.exe >nul 2>&1
    pause
    exit /b 1
)


echo Copying 32-bit thumbnail handler...

copy /y "%SOURCE_DLL32%" "%TARGET_DLL32%" >nul

if errorlevel 1 (
    echo.
    echo ERROR: Unable to copy:
    echo %TARGET_DLL32%
    echo.
    start explorer.exe >nul 2>&1
    pause
    exit /b 1
)


REM ======================================================================
REM Register 64-bit handler
REM ======================================================================

echo Registering 64-bit thumbnail handler...

"%REGSVR32_64%" /s "%TARGET_DLL64%"

if errorlevel 1 (
    echo.
    echo ERROR: 64-bit DLL registration failed.
    echo.
    start explorer.exe >nul 2>&1
    pause
    exit /b 1
)


REM ======================================================================
REM Register 32-bit handler
REM ======================================================================

echo Registering 32-bit thumbnail handler...

"%REGSVR32_32%" /s "%TARGET_DLL32%"

if errorlevel 1 (
    echo.
    echo ERROR: 32-bit DLL registration failed.
    echo.
    start explorer.exe >nul 2>&1
    pause
    exit /b 1
)


REM ======================================================================
REM Restart Explorer
REM ======================================================================

start explorer.exe


echo.
echo ============================================================
echo Installation completed successfully.
echo.
echo Installed 64-bit handler:
echo %TARGET_DLL64%
echo.
echo Installed 32-bit handler:
echo %TARGET_DLL32%
echo.
echo Thumbnail support is enabled for:
echo   .wfs
echo   .apk
echo   .aab
echo ============================================================
echo.

pause
endlocal
exit /b 0